﻿#pragma strict
var hero1 : GameObject;
var ray: Ray;
var hit: RaycastHit;
var gridSpacing = 1.0; 
var target: GameObject;
var newHero : GameObject;
var objectToMove : GameObject;
var nextNameNumber = 0;
var enemy : GameObject;
var choice ="RedTower";

function Start () {

}

function MoveObject (thisTransform : Transform, startPos : Vector3, endPos : Vector3, time : float) {
var i = 0.0;
var rate = 1.0/time;
while (i < 1.0) {
i += Time.deltaTime * rate;
thisTransform.position = Vector3.Lerp(startPos, endPos, i);
yield;
}
}

public static var whichHero = 1;

function OnGUI () {
    // Make a background box
    GUI.Box (Rect (10,10,100,90), "Loader Menu");

    // Make the first button. If it is pressed, Application.Loadlevel (1) will be executed
    if (GUI.Button (Rect (20,40,80,20), "Red")) {
        whichHero = 1;
		Debug.Log("Hero "+whichHero+" chosen");
    }

    // Make the second button.
    if (GUI.Button (Rect (20,70,80,20), "Green")) {
        whichHero = 2;
		Debug.Log("Hero "+whichHero+" chosen");
    }
}

function Update () {

	
if (whichHero==1)
	choice="RedTower";
else
	choice="Tower";

	if(Input.GetMouseButtonDown(0)) 	
		{
		   
			ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			if (Physics.Raycast(ray, hit, 100)) {
					if (hit.collider.name=="Plane") newHero=Instantiate(hero1, hit.point + Vector3(0, 1, 0), Quaternion.identity);
			}	 
		    newHero.name = "hero"+nextNameNumber;
			objectToMove = GameObject.Find("hero"+nextNameNumber);
			//target = GameObject.Find("Red Cube 1");
			enemy = FindClosestEnemy(objectToMove);
			Debug.Log (enemy.name);
			Debug.Log ("object " + objectToMove.name + " will move to " + enemy.name);
			nextNameNumber++;
			
			//hero1.transform.position = Vector3.MoveTowards(transform.position, target.gameObject.transform.position, 10);    	
			MoveObject (objectToMove.transform, objectToMove.transform.position, enemy.transform.position, 1);
		    	
		}
	}	
	function FindClosestEnemy (whichObject : GameObject) : GameObject {
		// Find all game objects with tag Tower
		var gos : GameObject[];
		gos = GameObject.FindGameObjectsWithTag(choice); 
		var closest : GameObject; 
		var distance = Mathf.Infinity; 
		var position = transform.position; 
		// Iterate through them and find the closest one
		for (var go : GameObject in gos)  { 
			var diff = (go.transform.position - whichObject.transform.position);
			var curDistance = diff.sqrMagnitude; 
			if (curDistance < distance) { 
				closest = go; 
				distance = curDistance; 
			} 
		} 
		return closest;	
	}
		

