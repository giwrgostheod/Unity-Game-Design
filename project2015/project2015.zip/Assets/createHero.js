#pragma strict

var hero1 : GameObject;
var hero2 : GameObject;
var ray: Ray;
var hit: RaycastHit;
var gridSpacing = 1.0; 

function Start () {

}

//Pass your mouse position to the below function and it will return the nearest grid co-ord to you.

function GetGridPosition (originalPosition : Vector3) {

	var newx = (Mathf.Round (originalPosition.x / gridSpacing) * gridSpacing);
	var newz = (Mathf.Round (originalPosition.z / gridSpacing) * gridSpacing);

	var convertPosition = new Vector3 (newx, (originalPosition.y), newz);
	return convertPosition;
}

function Update () {
/*if(Input.GetMouseButtonDown(0))
//0 is for when the left button is clicked, 1 is for the right
Instantiate(hero1,transform.position,Quaternion.identity);

 ray = Camera.main.ScreenPointToRay(Input.mousePosition);
if (Physics.Raycast(ray, hit, 100)) {

 Debug.Log ("Hit point: " + hit.point + " Grid Position: " + GetGridPosition (hit.point));
}*/

if(Input.GetMouseButtonDown(0)) 	
	{
		ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		if (Physics.Raycast(ray, hit, 100)) {
				if (hit.collider.name=="Plane") Instantiate(hero1, hit.point + Vector3(0, 1, 0), Quaternion.identity);
			}
			
	} 
	
}